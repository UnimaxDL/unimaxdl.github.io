@echo off
title UnimaxDL - Download FFmpeg Muxer
echo Downloading static FFmpeg muxer for 4K/8K stream combining...
powershell -Command "Invoke-WebRequest -Uri https://github.com/yt-dlp/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip -OutFile ffmpeg.zip"
powershell -Command "Expand-Archive ffmpeg.zip -DestinationPath . -Force"
move ffmpeg-master-latest-win64-gpl\bin\ffmpeg.exe bin\win-x64\ffmpeg.exe
del ffmpeg.zip
echo FFmpeg installation complete!
pause
