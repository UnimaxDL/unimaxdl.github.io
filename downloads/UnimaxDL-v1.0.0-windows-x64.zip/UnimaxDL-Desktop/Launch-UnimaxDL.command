#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
echo "Starting UnimaxDL Companion v1.0.0..."
chmod +x "$DIR/bin/darwin/yt-dlp"
open "$DIR/src/renderer/index.html"
