@echo off
title UnimaxDL Companion v1.0.0
cd /d "%~dp0"
echo ========================================================
echo    UnimaxDL Companion Desktop Engine v1.0.0
echo ========================================================
echo Checking bundled yt-dlp and ffmpeg binaries...
if exist "bin\win-x64\yt-dlp.exe" (
    echo [OK] Bundled yt-dlp binary detected.
) else (
    echo [ERROR] yt-dlp binary missing from bin\win-x64!
)
if exist "bin\win-x64\ffmpeg.exe" (
    echo [OK] Bundled static FFmpeg detected.
) else (
    echo [ERROR] FFmpeg missing from bin\win-x64!
)
echo Launching UnimaxDL...
start "" "src\renderer\index.html"
echo UnimaxDL Companion is active.
pause
