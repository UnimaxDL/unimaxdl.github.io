const { spawn } = require('child_process');
const BinaryResolver = require('./binary-resolver');

class BinaryUpdater {
  static async updateYtDlp() {
    return new Promise((resolve, reject) => {
      let binaries;
      try {
        binaries = BinaryResolver.getBinaryPaths();
      } catch (e) {
        return reject(e);
      }

      const child = spawn(binaries.ytdlp, ['-U'], { windowsHide: true });

      let output = '';
      child.stdout.on('data', (d) => { output += d.toString(); });
      child.stderr.on('data', (d) => { output += d.toString(); });

      child.on('close', (code) => {
        if (code === 0) {
          resolve({ success: true, log: output.trim() });
        } else {
          reject(new Error(`Update failed with code ${code}: ${output.trim()}`));
        }
      });

      child.on('error', (err) => reject(err));
    });
  }
}

module.exports = BinaryUpdater;
