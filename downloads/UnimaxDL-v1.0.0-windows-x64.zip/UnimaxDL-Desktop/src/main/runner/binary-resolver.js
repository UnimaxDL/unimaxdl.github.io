const path = require('path');
const fs = require('fs');

let electronApp = null;
try {
  const electron = require('electron');
  electronApp = electron.app;
} catch (_) {
  electronApp = null;
}

class BinaryResolver {
  static getPlatformSubdir() {
    const platform = process.platform;
    const arch = process.arch;

    if (platform === 'win32') return 'win-x64';
    if (platform === 'darwin') return arch === 'arm64' ? 'mac-arm64' : 'mac-x64';
    if (platform === 'linux') return 'linux-x64';
    throw new Error(`Unsupported operating platform: ${platform} ${arch}`);
  }

  static getBinaryPaths() {
    const isPackaged = electronApp ? electronApp.isPackaged : false;
    const platformDir = this.getPlatformSubdir();
    const isWindows = process.platform === 'win32';

    const ytdlpFileName = isWindows ? 'yt-dlp.exe' : 'yt-dlp';
    const ffmpegFileName = isWindows ? 'ffmpeg.exe' : 'ffmpeg';
    const ffprobeFileName = isWindows ? 'ffprobe.exe' : 'ffprobe';

    let baseBinDir;
    if (isPackaged && process.resourcesPath) {
      baseBinDir = path.join(process.resourcesPath, 'app.asar.unpacked', 'bin', platformDir);
    } else {
      baseBinDir = path.join(__dirname, '..', '..', '..', 'bin', platformDir);
    }

    const ytdlpPath = path.join(baseBinDir, ytdlpFileName);
    const ffmpegPath = path.join(baseBinDir, ffmpegFileName);
    const ffprobePath = path.join(baseBinDir, ffprobeFileName);

    if (!fs.existsSync(ytdlpPath)) {
      throw new Error(`yt-dlp binary not found at: ${ytdlpPath}`);
    }
    if (!fs.existsSync(ffmpegPath)) {
      throw new Error(`ffmpeg binary not found at: ${ffmpegPath}`);
    }

    if (process.platform !== 'win32') {
      try {
        fs.chmodSync(ytdlpPath, 0o755);
        fs.chmodSync(ffmpegPath, 0o755);
        if (fs.existsSync(ffprobePath)) {
          fs.chmodSync(ffprobePath, 0o755);
        }
      } catch (err) {
        console.warn('Execution permissions warning:', err.message);
      }
    }

    return {
      ytdlp: ytdlpPath,
      ffmpeg: ffmpegPath,
      ffprobe: ffprobePath
    };
  }
}

module.exports = BinaryResolver;
