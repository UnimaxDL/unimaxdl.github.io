const { spawn } = require('child_process');
const path = require('path');
const BinaryResolver = require('./binary-resolver');

class YtDlpRunner {
  constructor() {
    this.binaries = BinaryResolver.getBinaryPaths();
    this.activeProcesses = new Map();
  }

  async extractMetadata(url) {
    return new Promise((resolve, reject) => {
      const args = [
        '--dump-single-json',
        '--no-playlist',
        '--no-warnings',
        '--no-call-home',
        '--js-runtimes', 'node',
        url
      ];

      const child = spawn(this.binaries.ytdlp, args, { windowsHide: true });
      let stdoutBuffer = '';
      let stderrBuffer = '';

      child.stdout.on('data', (data) => {
        stdoutBuffer += data.toString();
      });

      child.stderr.on('data', (data) => {
        stderrBuffer += data.toString();
      });

      child.on('close', (code) => {
        if (code === 0) {
          try {
            const parsed = JSON.parse(stdoutBuffer);
            resolve(parsed);
          } catch (e) {
            reject(new Error(`Failed to parse metadata JSON: ${e.message}`));
          }
        } else {
          reject(new Error(`yt-dlp metadata query exited with code ${code}: ${stderrBuffer}`));
        }
      });

      child.on('error', (err) => reject(err));
    });
  }

  startDownload(jobId, options, onProgress, onComplete, onError) {
    const { url, outputDir, formatId, isAudioOnly } = options;
    const outputTemplate = path.join(outputDir, '%(title)s.%(ext)s');

    const args = [
      '--ffmpeg-location', path.dirname(this.binaries.ffmpeg),
      '--newline',
      '--no-mtime',
      '--js-runtimes', 'node',
      '-o', outputTemplate,
      '--progress-template', 'PROGRESS:%(progress._percent_str)s|%(progress._speed_str)s|%(progress._eta_str)s'
    ];

    if (isAudioOnly) {
      args.push(
        '-x',
        '--audio-format', 'mp3',
        '--audio-quality', '320K'
      );
    } else {
      args.push(
        '-f', formatId || 'bv*+ba/b',
        '--merge-output-format', 'mp4'
      );
    }

    args.push(url);

    const child = spawn(this.binaries.ytdlp, args, { windowsHide: true });
    this.activeProcesses.set(jobId, child);

    child.stdout.on('data', (chunk) => {
      const lines = chunk.toString().split('\n');
      for (const line of lines) {
        if (line.startsWith('PROGRESS:')) {
          const payload = line.replace('PROGRESS:', '').trim();
          const parts = payload.split('|');
          if (parts.length >= 3) {
            const rawPercent = parts[0].replace('%', '').trim();
            const percent = parseFloat(rawPercent) || 0;
            const speed = parts[1].trim();
            const eta = parts[2].trim();

            if (typeof onProgress === 'function') {
              onProgress({
                jobId,
                percent,
                speed,
                eta
              });
            }
          }
        }
      }
    });

    let stderrBuffer = '';
    child.stderr.on('data', (data) => {
      stderrBuffer += data.toString();
    });

    child.on('close', (code) => {
      this.activeProcesses.delete(jobId);
      if (code === 0) {
        if (typeof onComplete === 'function') {
          onComplete({ jobId });
        }
      } else {
        if (typeof onError === 'function') {
          onError(new Error(`Download failed with exit code ${code}: ${stderrBuffer}`));
        }
      }
    });

    child.on('error', (err) => {
      this.activeProcesses.delete(jobId);
      if (typeof onError === 'function') {
        onError(err);
      }
    });
  }

  cancelDownload(jobId) {
    const child = this.activeProcesses.get(jobId);
    if (child) {
      if (process.platform === 'win32') {
        spawn('taskkill', ['/pid', child.pid, '/f', '/t']);
      } else {
        child.kill('SIGTERM');
      }
      this.activeProcesses.delete(jobId);
      return true;
    }
    return false;
  }
}

module.exports = YtDlpRunner;
