const { clipboard } = require('electron');

class ClipboardWatcher {
  constructor(onUrlDetected) {
    this.onUrlDetected = onUrlDetected;
    this.lastText = '';
    this.intervalId = null;

    this.mediaPatterns = [
      /https?:\/\/(www\.)?(youtube\.com|youtu\.be)\/.+/i,
      /https?:\/\/(www\.)?tiktok\.com\/.+/i,
      /https?:\/\/(www\.)?instagram\.com\/(p|reel|tv)\/.+/i,
      /https?:\/\/(www\.)?(twitter\.com|x\.com)\/.+\/status\/.+/i,
      /https?:\/\/(www\.)?facebook\.com\/.+/i,
      /https?:\/\/(www\.)?fb\.watch\/.+/i,
      /https?:\/\/(www\.)?reddit\.com\/r\/.+\/comments\/.+/i,
      /https?:\/\/(www\.)?soundcloud\.com\/.+/i,
      /https?:\/\/(www\.)?twitch\.tv\/.+/i,
      /https?:\/\/(www\.)?pin\.it\/.+/i,
      /https?:\/\/(www\.)?pinterest\.(com|[a-z]{2,3})\/pin\/.+/i
    ];
  }

  start(intervalMs = 1500) {
    if (this.intervalId) return;

    try {
      this.lastText = clipboard.readText().trim();
    } catch (_) {
      this.lastText = '';
    }

    this.intervalId = setInterval(() => {
      this.checkClipboard();
    }, intervalMs);
  }

  stop() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
  }

  checkClipboard() {
    try {
      const currentText = clipboard.readText().trim();
      if (!currentText || currentText === this.lastText) return;

      this.lastText = currentText;

      const isMatch = this.mediaPatterns.some((pattern) => pattern.test(currentText));
      if (isMatch && typeof this.onUrlDetected === 'function') {
        this.onUrlDetected(currentText);
      }
    } catch (_) {}
  }
}

module.exports = ClipboardWatcher;
