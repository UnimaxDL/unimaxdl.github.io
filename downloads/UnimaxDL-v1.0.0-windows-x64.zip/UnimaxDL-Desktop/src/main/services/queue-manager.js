class QueueManager {
  constructor(runner, maxConcurrent = 3) {
    this.runner = runner;
    this.maxConcurrent = maxConcurrent;
    this.activeJobs = new Map();
    this.queuedJobs = [];
  }

  enqueue(jobOptions, callbacks) {
    const jobId = jobOptions.jobId || `job_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const job = {
      id: jobId,
      options: { ...jobOptions, jobId },
      callbacks,
      status: 'queued',
      addedAt: Date.now()
    };

    this.queuedJobs.push(job);
    this.processQueue();
    return jobId;
  }

  processQueue() {
    while (this.activeJobs.size < this.maxConcurrent && this.queuedJobs.length > 0) {
      const nextJob = this.queuedJobs.shift();
      this.runJob(nextJob);
    }
  }

  runJob(job) {
    this.activeJobs.set(job.id, job);
    job.status = 'running';

    this.runner.startDownload(
      job.id,
      job.options,
      (progressData) => {
        if (job.callbacks && typeof job.callbacks.onProgress === 'function') {
          job.callbacks.onProgress(progressData);
        }
      },
      (completeData) => {
        this.activeJobs.delete(job.id);
        job.status = 'completed';
        if (job.callbacks && typeof job.callbacks.onComplete === 'function') {
          job.callbacks.onComplete(completeData);
        }
        this.processQueue();
      },
      (error) => {
        this.activeJobs.delete(job.id);
        job.status = 'error';
        if (job.callbacks && typeof job.callbacks.onError === 'function') {
          job.callbacks.onError(error);
        }
        this.processQueue();
      }
    );
  }

  cancel(jobId) {
    // Check if in queue
    const queuedIndex = this.queuedJobs.findIndex((j) => j.id === jobId);
    if (queuedIndex !== -1) {
      this.queuedJobs.splice(queuedIndex, 1);
      return true;
    }

    // Check if active
    if (this.activeJobs.has(jobId)) {
      const cancelled = this.runner.cancelDownload(jobId);
      this.activeJobs.delete(jobId);
      this.processQueue();
      return cancelled;
    }

    return false;
  }

  getStatus() {
    return {
      activeCount: this.activeJobs.size,
      queuedCount: this.queuedJobs.length,
      maxConcurrent: this.maxConcurrent
    };
  }
}

module.exports = QueueManager;
