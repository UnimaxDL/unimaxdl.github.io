const { app, BrowserWindow, ipcMain, dialog, Tray, Menu, shell } = require('electron');
const path = require('path');
const YtDlpRunner = require('./runner/yt-dlp-runner');
const BinaryUpdater = require('./runner/updater');
const ClipboardWatcher = require('./services/clipboard-watcher');
const QueueManager = require('./services/queue-manager');

let mainWindow = null;
let tray = null;
let runner = null;
let queueManager = null;
let clipboardWatcher = null;

const PROTOCOL = 'unimaxdl';

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', (_event, commandLine) => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.show();
      mainWindow.focus();
    }
    const deepUrl = commandLine.find((arg) => arg.startsWith(`${PROTOCOL}://`));
    if (deepUrl && mainWindow) {
      handleDeepLink(deepUrl);
    }
  });
}

function handleDeepLink(rawUrl) {
  try {
    const parsed = new URL(rawUrl);
    const target = parsed.searchParams.get('url');
    if (target && mainWindow) {
      mainWindow.webContents.send('captured:url', target);
    }
  } catch (err) {
    console.error('Deep link parse error:', err.message);
  }
}

function createWindow() {
  const iconPath = process.platform === 'win32'
    ? path.join(__dirname, '..', '..', 'assets', 'icons', 'icon.ico')
    : path.join(__dirname, '..', '..', 'assets', 'icons', 'icon.png');

  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    minWidth: 960,
    minHeight: 640,
    backgroundColor: '#07070a',
    icon: iconPath,
    show: false,
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, '..', 'preload', 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });

  mainWindow.loadFile(path.join(__dirname, '..', 'renderer', 'index.html'));

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });

  mainWindow.on('close', (event) => {
    if (!app.isQuitting) {
      event.preventDefault();
      mainWindow.hide();
    }
    return false;
  });
}

function initTray() {
  const trayIconPath = process.platform === 'win32'
    ? path.join(__dirname, '..', '..', 'assets', 'tray', 'tray-win.ico')
    : path.join(__dirname, '..', '..', 'assets', 'tray', 'tray-mac.png');

  tray = new Tray(trayIconPath);
  const contextMenu = Menu.buildFromTemplate([
    {
      label: 'Open UnimaxDL',
      click: () => {
        if (mainWindow) {
          mainWindow.show();
          mainWindow.focus();
        }
      }
    },
    { type: 'separator' },
    {
      label: 'Check Engine Update',
      click: async () => {
        try {
          const res = await BinaryUpdater.updateYtDlp();
          dialog.showMessageBox(mainWindow, {
            type: 'info',
            title: 'Engine Update',
            message: res.log || 'Engine is up to date.'
          });
        } catch (e) {
          dialog.showMessageBox(mainWindow, {
            type: 'warning',
            title: 'Update Notice',
            message: e.message
          });
        }
      }
    },
    { type: 'separator' },
    {
      label: 'Exit',
      click: () => {
        app.isQuitting = true;
        app.quit();
      }
    }
  ]);

  tray.setToolTip('UnimaxDL Universal Downloader');
  tray.setContextMenu(contextMenu);
  tray.on('double-click', () => {
    if (mainWindow) {
      mainWindow.show();
      mainWindow.focus();
    }
  });
}

function registerIpcHandlers() {
  runner = new YtDlpRunner();
  queueManager = new QueueManager(runner, 3);

  ipcMain.handle('media:extract', async (_event, url) => {
    return await runner.extractMetadata(url);
  });

  ipcMain.handle('media:download', (_event, options) => {
    const jobId = queueManager.enqueue(options, {
      onProgress: (progressData) => {
        if (mainWindow && !mainWindow.isDestroyed()) {
          mainWindow.webContents.send('download:progress', progressData);
        }
      },
      onComplete: (completeData) => {
        if (mainWindow && !mainWindow.isDestroyed()) {
          mainWindow.webContents.send('download:complete', completeData);
        }
      },
      onError: (error) => {
        if (mainWindow && !mainWindow.isDestroyed()) {
          mainWindow.webContents.send('download:error', {
            jobId: options.jobId,
            message: error.message
          });
        }
      }
    });

    return { status: 'queued', jobId };
  });

  ipcMain.handle('media:cancel', (_event, jobId) => {
    return queueManager.cancel(jobId);
  });

  ipcMain.handle('system:select-directory', async () => {
    const result = await dialog.showOpenDialog(mainWindow, {
      title: 'Select Download Folder',
      properties: ['openDirectory', 'createDirectory']
    });
    return result.canceled ? null : result.filePaths[0];
  });

  ipcMain.handle('system:get-default-dir', () => {
    return app.getPath('downloads');
  });

  ipcMain.handle('system:update-engine', async () => {
    return await BinaryUpdater.updateYtDlp();
  });

  ipcMain.handle('system:open-path', async (_event, targetPath) => {
    if (targetPath) {
      await shell.openPath(targetPath);
      return true;
    }
    return false;
  });

  ipcMain.handle('system:open-external', async (_event, targetUrl) => {
    if (targetUrl) {
      await shell.openExternal(targetUrl);
      return true;
    }
    return false;
  });
}

app.whenReady().then(() => {
  if (process.defaultApp) {
    if (process.argv.length >= 2) {
      app.setAsDefaultProtocolClient(PROTOCOL, process.execPath, [path.resolve(process.argv[1])]);
    }
  } else {
    app.setAsDefaultProtocolClient(PROTOCOL);
  }

  createWindow();
  initTray();
  registerIpcHandlers();

  clipboardWatcher = new ClipboardWatcher((matchedUrl) => {
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('captured:url', matchedUrl);
    }
  });
  clipboardWatcher.start();
});

app.on('open-url', (event, url) => {
  event.preventDefault();
  handleDeepLink(url);
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
  else if (mainWindow) {
    mainWindow.show();
    mainWindow.focus();
  }
});

app.on('before-quit', () => {
  app.isQuitting = true;
  if (clipboardWatcher) clipboardWatcher.stop();
});
