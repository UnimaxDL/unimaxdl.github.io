const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('UnimaxAPI', {
  extractInfo: (url) => ipcRenderer.invoke('media:extract', url),
  startDownload: (options) => ipcRenderer.invoke('media:download', options),
  cancelDownload: (jobId) => ipcRenderer.invoke('media:cancel', jobId),
  selectDirectory: () => ipcRenderer.invoke('system:select-directory'),
  getDefaultDownloadDir: () => ipcRenderer.invoke('system:get-default-dir'),
  updateEngine: () => ipcRenderer.invoke('system:update-engine'),
  openInFolder: (dirPath) => ipcRenderer.invoke('system:open-path', dirPath),
  openExternal: (url) => ipcRenderer.invoke('system:open-external', url),

  onDownloadProgress: (callback) => {
    const subscription = (_event, data) => callback(data);
    ipcRenderer.on('download:progress', subscription);
    return () => ipcRenderer.removeListener('download:progress', subscription);
  },

  onDownloadCompleted: (callback) => {
    const subscription = (_event, data) => callback(data);
    ipcRenderer.on('download:complete', subscription);
    return () => ipcRenderer.removeListener('download:complete', subscription);
  },

  onDownloadError: (callback) => {
    const subscription = (_event, data) => callback(data);
    ipcRenderer.on('download:error', subscription);
    return () => ipcRenderer.removeListener('download:error', subscription);
  },

  onExternalUrlCaptured: (callback) => {
    const subscription = (_event, url) => callback(url);
    ipcRenderer.on('captured:url', subscription);
    return () => ipcRenderer.removeListener('captured:url', subscription);
  }
});
