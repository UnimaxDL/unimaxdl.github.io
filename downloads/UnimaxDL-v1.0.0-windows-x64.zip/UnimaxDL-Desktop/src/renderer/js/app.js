document.addEventListener('DOMContentLoaded', async () => {
  // Elements
  const dirPickerBtn = document.getElementById('dir-picker');
  const currentDirLabel = document.getElementById('current-dir-label');
  const btnUpdateEngine = document.getElementById('btn-update-engine');
  
  const clipboardBanner = document.getElementById('clipboard-banner');
  const clipboardUrlText = document.getElementById('clipboard-url-text');
  const btnPasteClipboard = document.getElementById('btn-paste-clipboard');
  
  const urlInput = document.getElementById('url-input');
  const btnResolve = document.getElementById('btn-resolve');
  const resolveSpinner = document.getElementById('resolve-spinner');
  const btnResolveLabel = document.getElementById('btn-resolve-label');
  
  const mediaCard = document.getElementById('media-card');
  const mediaThumbImg = document.getElementById('media-thumb-img');
  const mediaDuration = document.getElementById('media-duration');
  const mediaTitle = document.getElementById('media-title');
  const mediaAuthor = document.getElementById('media-author');
  const formatOptionsGrid = document.getElementById('format-options-grid');
  const btnStartDownload = document.getElementById('btn-start-download');
  
  const queueTabs = document.querySelectorAll('.queue-tab');
  const queueList = document.getElementById('queue-list');
  const emptyQueueMsg = document.getElementById('empty-queue-msg');
  const badgeActiveCount = document.getElementById('badge-active-count');
  const badgeCompletedCount = document.getElementById('badge-completed-count');

  // Application State
  let currentDownloadDir = '';
  let resolvedMedia = null;
  let selectedFormat = null;
  let activeTab = 'active';
  
  const jobs = new Map(); // id -> job object

  // 1. Initialize Download Directory
  try {
    currentDownloadDir = await RendererIPC.getDefaultDownloadDir();
    currentDirLabel.textContent = currentDownloadDir;
    currentDirLabel.title = currentDownloadDir;
  } catch (_) {
    currentDownloadDir = 'Downloads';
    currentDirLabel.textContent = 'Downloads';
  }

  dirPickerBtn.addEventListener('click', async () => {
    try {
      const selected = await RendererIPC.selectDirectory();
      if (selected) {
        currentDownloadDir = selected;
        currentDirLabel.textContent = selected;
        currentDirLabel.title = selected;
      }
    } catch (err) {
      console.error('Failed to select directory:', err);
    }
  });

  // 2. Engine Update Check
  btnUpdateEngine.addEventListener('click', async () => {
    btnUpdateEngine.style.opacity = '0.5';
    try {
      const res = await RendererIPC.updateEngine();
      alert(res.log || 'yt-dlp is up to date.');
    } catch (err) {
      alert(`Update error: ${err.message}`);
    } finally {
      btnUpdateEngine.style.opacity = '1';
    }
  });

  // 3. Clipboard & External URL Watcher
  RendererIPC.subscribeClipboard((capturedUrl) => {
    if (capturedUrl && capturedUrl !== urlInput.value) {
      clipboardUrlText.textContent = capturedUrl.length > 50 ? capturedUrl.substring(0, 47) + '...' : capturedUrl;
      clipboardBanner.classList.add('active');
      btnPasteClipboard.onclick = () => {
        urlInput.value = capturedUrl;
        clipboardBanner.classList.remove('active');
        triggerResolve();
      };
    }
  });

  // 4. Resolve Media Flow
  btnResolve.addEventListener('click', triggerResolve);
  urlInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') triggerResolve();
  });

  async function triggerResolve() {
    const rawUrl = urlInput.value.trim();
    if (!rawUrl) return;

    btnResolve.disabled = true;
    resolveSpinner.classList.add('active');
    btnResolveLabel.textContent = 'Analyzing...';
    mediaCard.classList.remove('visible');

    try {
      const data = await RendererIPC.extractInfo(rawUrl);
      resolvedMedia = data;
      displayMediaCard(data);
    } catch (err) {
      alert(`Extraction Failed: ${err.message}`);
    } finally {
      btnResolve.disabled = false;
      resolveSpinner.classList.remove('active');
      btnResolveLabel.textContent = 'Resolve Media';
    }
  }

  function displayMediaCard(data) {
    mediaTitle.textContent = data.title || 'Untitled Stream';
    mediaAuthor.textContent = data.uploader || data.channel || 'Unknown Creator';
    mediaThumbImg.src = data.thumbnail || '';
    mediaDuration.textContent = UIComponents.formatDuration(data.duration);

    // Clear old options
    formatOptionsGrid.innerHTML = '';

    const chipsContainer = UIComponents.renderFormatChips(data.formats, (chosen) => {
      selectedFormat = chosen;
    });

    formatOptionsGrid.appendChild(chipsContainer);
    mediaCard.classList.add('visible');
  }

  // 5. Start Download Flow
  btnStartDownload.addEventListener('click', async () => {
    if (!resolvedMedia || !selectedFormat) return;

    const jobId = `dl_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const job = {
      id: jobId,
      title: resolvedMedia.title || 'Media Stream',
      url: urlInput.value.trim(),
      outputDir: currentDownloadDir,
      formatId: selectedFormat.formatId,
      formatLabel: selectedFormat.label,
      isAudioOnly: selectedFormat.isAudioOnly,
      status: 'active',
      percent: 0,
      speed: '0.0 MB/s',
      eta: 'Connecting...',
      completedAt: null
    };

    jobs.set(jobId, job);
    updateQueueView();

    try {
      await RendererIPC.startDownload({
        jobId,
        url: job.url,
        outputDir: job.outputDir,
        formatId: job.formatId,
        isAudioOnly: job.isAudioOnly
      });
    } catch (err) {
      job.status = 'error';
      updateJobError(jobId, err.message);
    }
  });

  // 6. Handle Download Progress & Events
  RendererIPC.subscribeProgress((data) => {
    const job = jobs.get(data.jobId);
    if (!job) return;

    job.percent = data.percent;
    job.speed = data.speed;
    job.eta = data.eta;

    const progressBar = document.getElementById(`progress-bar-${job.id}`);
    const speedLabel = document.getElementById(`speed-${job.id}`);
    const etaLabel = document.getElementById(`eta-${job.id}`);
    const percentLabel = document.getElementById(`percent-label-${job.id}`);

    if (progressBar) progressBar.style.width = `${Math.min(100, Math.max(0, data.percent))}%`;
    if (speedLabel) speedLabel.textContent = data.speed;
    if (etaLabel) etaLabel.textContent = data.eta ? `ETA ${data.eta}` : '';
    if (percentLabel) percentLabel.textContent = `${Math.round(data.percent)}%`;
  });

  RendererIPC.subscribeCompleted((data) => {
    const job = jobs.get(data.jobId);
    if (!job) return;

    job.status = 'completed';
    job.completedAt = Date.now();
    job.percent = 100;

    const progressBar = document.getElementById(`progress-bar-${job.id}`);
    const etaLabel = document.getElementById(`eta-${job.id}`);
    const percentLabel = document.getElementById(`percent-label-${job.id}`);
    const actionsBox = document.getElementById(`actions-${job.id}`);

    if (progressBar) {
      progressBar.style.width = '100%';
      progressBar.classList.add('complete');
    }
    if (etaLabel) etaLabel.textContent = 'Finished';
    if (percentLabel) percentLabel.textContent = '100%';

    if (actionsBox) {
      actionsBox.innerHTML = `
        <button class="card-action-btn success" title="Open Download Folder" id="btn-open-${job.id}">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>
          </svg>
        </button>
      `;

      document.getElementById(`btn-open-${job.id}`).onclick = () => {
        RendererIPC.openInFolder(job.outputDir);
      };
    }

    updateBadges();
  });

  RendererIPC.subscribeError((data) => {
    updateJobError(data.jobId, data.message);
  });

  function updateJobError(jobId, message) {
    const job = jobs.get(jobId);
    if (!job) return;

    job.status = 'error';
    const progressBar = document.getElementById(`progress-bar-${job.id}`);
    const etaLabel = document.getElementById(`eta-${job.id}`);

    if (progressBar) progressBar.classList.add('error');
    if (etaLabel) {
      etaLabel.textContent = 'Failed';
      etaLabel.title = message;
      etaLabel.style.color = 'var(--color-danger)';
    }

    updateBadges();
  }

  // 7. Queue View Management
  function updateQueueView() {
    queueList.innerHTML = '';
    const relevantJobs = Array.from(jobs.values()).filter((j) => {
      if (activeTab === 'active') return j.status === 'active';
      return j.status === 'completed' || j.status === 'error';
    });

    if (relevantJobs.length === 0) {
      emptyQueueMsg.style.display = 'block';
      emptyQueueMsg.textContent = activeTab === 'active' 
        ? 'No active downloads. Paste a link above to begin.' 
        : 'No completed downloads in this session.';
      queueList.appendChild(emptyQueueMsg);
    } else {
      emptyQueueMsg.style.display = 'none';
      relevantJobs.forEach((job) => {
        const itemEl = UIComponents.createQueueItem(job);
        queueList.appendChild(itemEl);

        const cancelBtn = document.getElementById(`btn-cancel-${job.id}`);
        if (cancelBtn) {
          cancelBtn.onclick = () => {
            RendererIPC.cancelDownload(job.id);
            job.status = 'cancelled';
            updateJobError(job.id, 'Cancelled by user');
          };
        }
      });
    }

    updateBadges();
  }

  function updateBadges() {
    let active = 0;
    let completed = 0;
    jobs.forEach((j) => {
      if (j.status === 'active') active++;
      if (j.status === 'completed') completed++;
    });

    badgeActiveCount.textContent = active;
    badgeCompletedCount.textContent = completed;
  }

  // 8. Tab Navigation
  queueTabs.forEach((tab) => {
    tab.addEventListener('click', () => {
      queueTabs.forEach((t) => t.classList.remove('active'));
      tab.classList.add('active');
      activeTab = tab.dataset.tab;
      updateQueueView();
    });
  });
});
