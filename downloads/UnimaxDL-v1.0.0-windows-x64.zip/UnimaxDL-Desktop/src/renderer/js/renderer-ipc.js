const RendererIPC = {
  async extractInfo(url) {
    if (!window.UnimaxAPI) throw new Error('UnimaxAPI native bridge is not available');
    return await window.UnimaxAPI.extractInfo(url);
  },

  async startDownload(options) {
    if (!window.UnimaxAPI) throw new Error('UnimaxAPI native bridge is not available');
    return await window.UnimaxAPI.startDownload(options);
  },

  async cancelDownload(jobId) {
    if (!window.UnimaxAPI) return false;
    return await window.UnimaxAPI.cancelDownload(jobId);
  },

  async selectDirectory() {
    if (!window.UnimaxAPI) return null;
    return await window.UnimaxAPI.selectDirectory();
  },

  async getDefaultDownloadDir() {
    if (!window.UnimaxAPI) return 'Downloads';
    return await window.UnimaxAPI.getDefaultDownloadDir();
  },

  async updateEngine() {
    if (!window.UnimaxAPI) return { success: false, log: 'Desktop bridge offline' };
    return await window.UnimaxAPI.updateEngine();
  },

  async openInFolder(dirPath) {
    if (!window.UnimaxAPI) return false;
    return await window.UnimaxAPI.openInFolder(dirPath);
  },

  subscribeProgress(callback) {
    if (window.UnimaxAPI) return window.UnimaxAPI.onDownloadProgress(callback);
    return () => {};
  },

  subscribeCompleted(callback) {
    if (window.UnimaxAPI) return window.UnimaxAPI.onDownloadCompleted(callback);
    return () => {};
  },

  subscribeError(callback) {
    if (window.UnimaxAPI) return window.UnimaxAPI.onDownloadError(callback);
    return () => {};
  },

  subscribeClipboard(callback) {
    if (window.UnimaxAPI) return window.UnimaxAPI.onExternalUrlCaptured(callback);
    return () => {};
  }
};
