const UIComponents = {
  formatDuration(seconds) {
    if (!seconds || isNaN(seconds)) return '00:00';
    const s = Math.floor(seconds);
    const hrs = Math.floor(s / 3600);
    const mins = Math.floor((s % 3600) / 60);
    const secs = s % 60;

    const pad = (n) => (n < 10 ? '0' + n : n);
    if (hrs > 0) {
      return `${hrs}:${pad(mins)}:${pad(secs)}`;
    }
    return `${pad(mins)}:${pad(secs)}`;
  },

  formatBytes(bytes) {
    if (!bytes || isNaN(bytes)) return '';
    const units = ['B', 'KB', 'MB', 'GB'];
    let size = bytes;
    let unitIndex = 0;
    while (size >= 1024 && unitIndex < units.length - 1) {
      size /= 1024;
      unitIndex++;
    }
    return `${size.toFixed(1)} ${units[unitIndex]}`;
  },

  renderFormatChips(formats, onSelect) {
    const container = document.createElement('div');
    container.className = 'format-options-grid';

    // Prioritize standard qualities: 2160p (4K), 1440p (2K), 1080p, 720p, 480p, 360p, and Audio
    const chipsData = [];

    // Filter available video formats
    const videoFormats = (formats || []).filter((f) => f.vcodec && f.vcodec !== 'none' && f.height);
    const heights = [2160, 1440, 1080, 720, 480, 360];

    for (const h of heights) {
      const match = videoFormats.find((f) => f.height === h);
      if (match) {
        const label = h >= 2160 ? `${h}p (4K UHD)` : h >= 1440 ? `${h}p (2K QHD)` : `${h}p`;
        chipsData.push({
          label,
          formatId: match.format_id,
          isAudioOnly: false,
          filesize: match.filesize || match.filesize_approx
        });
      }
    }

    // Best Video default if none matched
    if (chipsData.length === 0) {
      chipsData.push({
        label: 'Best Quality (Auto MP4)',
        formatId: 'bv*+ba/b',
        isAudioOnly: false
      });
    }

    // Always add MP3 Audio Option
    chipsData.push({
      label: 'Audio Only (MP3 320k)',
      formatId: 'ba/b',
      isAudioOnly: true
    });

    let selectedChip = null;

    chipsData.forEach((item, index) => {
      const chip = document.createElement('div');
      chip.className = `format-chip ${index === 0 ? 'selected' : ''}`;
      chip.textContent = item.label;
      if (index === 0) {
        selectedChip = item;
      }

      chip.addEventListener('click', () => {
        container.querySelectorAll('.format-chip').forEach((c) => c.classList.remove('selected'));
        chip.classList.add('selected');
        onSelect(item);
      });

      container.appendChild(chip);
    });

    onSelect(selectedChip);
    return container;
  },

  createQueueItem(job) {
    const card = document.createElement('div');
    card.className = 'queue-card';
    card.id = `queue-card-${job.id}`;

    card.innerHTML = `
      <div class="queue-card-left">
        <div class="queue-item-title" title="${job.title}">${job.title}</div>
        <div class="queue-item-meta">
          <span class="queue-item-format">${job.formatLabel || 'MP4'}</span>
          <span class="queue-item-speed" id="speed-${job.id}">${job.speed || '0.0 MB/s'}</span>
          <span class="queue-item-eta" id="eta-${job.id}">${job.eta ? 'ETA ' + job.eta : 'Preparing...'}</span>
          <span class="queue-item-percent" id="percent-label-${job.id}">0%</span>
        </div>
        <div class="progress-track">
          <div class="progress-bar" id="progress-bar-${job.id}"></div>
        </div>
      </div>
      <div class="queue-card-right" id="actions-${job.id}">
        <button class="card-action-btn danger" id="btn-cancel-${job.id}" title="Cancel Download">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        </button>
      </div>
    `;

    return card;
  }
};
