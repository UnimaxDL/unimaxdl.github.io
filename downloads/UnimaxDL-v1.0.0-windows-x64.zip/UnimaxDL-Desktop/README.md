# UnimaxDL Desktop Application

Standalone cross-platform desktop companion application for UnimaxDL on Windows, macOS, and Linux.

## Architecture Highlights
- **100% Local Execution:** Processes all video resolutions (4K, 8K, 1080p60) and DASH stream muxing directly on the user host machine with zero Render server bandwidth consumption.
- **Bundled Engine Binaries:** yt-dlp and ffmpeg binaries are unpacked via ASAR unpack configurations into isolated host paths for high-throughput stream extraction.
- **Smart System Clipboard Watcher:** Background daemon captures video and audio links from popular platforms (YouTube, TikTok, Instagram, Twitter/X, Reddit, etc.) with instant resolution.
- **Multi-Slot Concurrent Queue:** Managed download queue with progress tracking, real-time download speeds, and cancel handlers.
- **System Tray Lifecycle:** Runs in the system tray with background window minimization and single-instance locks.
- **Custom Protocol Handler:** Deep linking via `unimaxdl://resolve?url=...` allows instant handoff from web browsers.

## Directory Structure
```
UnimaxDL-Desktop/
├── .github/workflows/
│   └── release-desktop.yml
├── assets/
│   ├── icons/
│   └── tray/
├── bin/
│   └── win-x64/
├── build/
│   ├── entitlements.mac.plist
│   └── installer.nsh
├── package.json
└── src/
    ├── main/
    │   ├── main.js
    │   ├── runner/
    │   │   ├── binary-resolver.js
    │   │   ├── updater.js
    │   │   └── yt-dlp-runner.js
    │   └── services/
    │       ├── clipboard-watcher.js
    │       └── queue-manager.js
    ├── preload/
    │   └── preload.js
    └── renderer/
        ├── index.html
        ├── css/
        │   ├── tokens.css
        │   └── main.css
        └── js/
            ├── app.js
            ├── renderer-ipc.js
            └── ui-components.js
```

## Development
```bash
npm install
npm start
```

## Packaging
```bash
# Windows (NSIS Installer & Portable EXE)
npm run dist:win

# macOS (DMG)
npm run dist:mac

# Linux (AppImage & DEB)
npm run dist:linux
```
