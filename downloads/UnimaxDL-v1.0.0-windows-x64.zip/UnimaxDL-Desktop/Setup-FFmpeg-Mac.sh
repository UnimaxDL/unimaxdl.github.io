#!/bin/bash
echo "Installing FFmpeg via Homebrew for hardware muxing..."
if command -v brew >/dev/null 2>&1; then
    brew install ffmpeg
else
    echo "Homebrew not detected. Please install Homebrew or FFmpeg manually."
fi
