#!/usr/bin/env bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
echo "Launching UnimaxDL Linux Companion..."
chmod +x "$DIR/bin/linux-x64/yt-dlp"
xdg-open "$DIR/src/renderer/index.html" 2>/dev/null || sensible-browser "$DIR/src/renderer/index.html"
